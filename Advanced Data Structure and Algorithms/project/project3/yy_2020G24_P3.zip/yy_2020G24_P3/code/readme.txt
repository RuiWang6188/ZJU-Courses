To run the program normally, you need to add all files under source code directory to your project's directory


