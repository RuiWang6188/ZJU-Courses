You can compile "Pow.c" to test the code with any compiler.

If you do not have any integrated development environment, you can also compile the code in the following steps:

1. Open cmd under current path.
2. Using command " gcc Pow.c -o Pow -g -Wall" to compile.
3. Using command "Pow.exe"  or  "Pow"  to run.

If you still failed, you can also double click "Pow.exe" to run .
