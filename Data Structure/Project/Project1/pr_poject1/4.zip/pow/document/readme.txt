Please read "Report.pdf" first.
The file "raw_data.pdf" is just some appendix datas.