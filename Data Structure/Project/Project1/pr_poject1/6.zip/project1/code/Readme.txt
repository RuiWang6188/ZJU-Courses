The project was developed by Visual Studio.
The C Source File is under:code\Project 1�� Performance Measurement (POW)\Project 1�� Performance Measurement (POW) 